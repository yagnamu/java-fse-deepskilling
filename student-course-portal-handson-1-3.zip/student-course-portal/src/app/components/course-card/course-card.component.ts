import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Course } from '../../models/course.model';
import { CreditLabelPipe } from '../../pipes/credit-label.pipe';
import { HighlightDirective } from '../../directives/highlight.directive';

@Component({
  selector: 'app-course-card',
  standalone: true,
  imports: [CommonModule, CreditLabelPipe, HighlightDirective],
  templateUrl: './course-card.component.html',
  styleUrls: ['./course-card.component.css']
})
export class CourseCardComponent implements OnChanges {
  // Hands-On 2, Task 3, Step 20
  @Input() course!: Course;

  // Hands-On 2, Task 3, Step 21
  @Output() enrollRequested = new EventEmitter<number>();

  // Hands-On 3, Task 2, Step 31
  isExpanded = false;

  // Hands-On 3, Task 1, Step 27 - toggled externally via enrollment status
  isEnrolled = false;

  // Hands-On 2, Task 2, Step 18
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['course']) {
      console.log(
        'CourseCardComponent course changed. Previous:',
        changes['course'].previousValue,
        'Current:',
        changes['course'].currentValue
      );
    }
  }

  onEnrollClick(): void {
    this.isEnrolled = !this.isEnrolled;
    this.enrollRequested.emit(this.course.id);
  }

  toggleExpanded(): void {
    this.isExpanded = !this.isExpanded;
  }

  // Hands-On 3, Task 2, Step 30
  get borderColor(): string {
    switch (this.course.gradeStatus) {
      case 'passed':
        return 'green';
      case 'failed':
        return 'red';
      default:
        return 'grey';
    }
  }

  // Hands-On 3, Task 2, Step 32
  // A getter keeps the template free of inline object literals/logic,
  // making [ngClass]='cardClasses' easy to read and the class the
  // single source of truth for which classes apply.
  get cardClasses(): Record<string, boolean> {
    return {
      'card--enrolled': this.isEnrolled,
      'card--full': this.course.credits >= 4,
      expanded: this.isExpanded
    };
  }
}
