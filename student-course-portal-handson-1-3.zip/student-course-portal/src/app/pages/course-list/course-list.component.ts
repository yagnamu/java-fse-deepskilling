import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CourseCardComponent } from '../../components/course-card/course-card.component';
import { Course } from '../../models/course.model';

@Component({
  selector: 'app-course-list',
  standalone: true,
  imports: [CommonModule, CourseCardComponent],
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit {
  // Hands-On 3, Task 1, Step 25
  isLoading = true;

  // Hands-On 2, Task 3, Step 22
  courses: Course[] = [
    { id: 1, name: 'Data Structures', code: 'CS101', credits: 4, gradeStatus: 'passed' },
    { id: 2, name: 'Operating Systems', code: 'CS102', credits: 3, gradeStatus: 'pending' },
    { id: 3, name: 'Database Systems', code: 'CS103', credits: 4, gradeStatus: 'failed' },
    { id: 4, name: 'Web Development', code: 'CS104', credits: 2, gradeStatus: 'passed' },
    { id: 5, name: 'Software Engineering', code: 'CS105', credits: 3, gradeStatus: 'pending' }
  ];

  selectedCourseId: number | null = null;

  ngOnInit(): void {
    // Hands-On 3, Task 1, Step 25: simulate loading delay
    setTimeout(() => {
      this.isLoading = false;
    }, 1500);
  }

  // Hands-On 3, Task 1, Step 26:
  // trackBy tells Angular how to identify each item in the list by a
  // stable id (course.id) instead of by object reference/position.
  // Without it, Angular destroys and re-creates every DOM node when the
  // array reference changes, even if only one item actually changed —
  // trackBy lets it patch just the changed item, which is much faster
  // for large lists.
  trackByCourseId(index: number, course: Course): number {
    return course.id;
  }

  // Hands-On 2, Task 3, Step 23
  onEnroll(courseId: number): void {
    console.log('Enrolling in course: ' + courseId);
    this.selectedCourseId = courseId;
  }
}
