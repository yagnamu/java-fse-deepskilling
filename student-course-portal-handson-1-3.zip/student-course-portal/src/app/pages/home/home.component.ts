import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy {
  // Hands-On 2, Task 1, Step 11: interpolation source
  portalName = 'Student Course Portal';

  // Hands-On 1, Task 2, Step 8: hardcoded stats row
  coursesAvailable = 12;
  enrolledCount = 3;
  gpa = 3.8;

  // Hands-On 2, Task 1, Step 12: property binding target
  isPortalActive = true;

  // Hands-On 2, Task 1, Step 13: event binding target
  message = '';

  // Hands-On 2, Task 1, Step 14: two-way binding target
  searchTerm = '';

  // Hands-On 2, Task 1, Step 13
  onEnrollClick(): void {
    this.message = 'Enrollment opened!';
  }

  // Hands-On 2, Task 1, Step 15:
  // [property]='value'  -> ONE-WAY binding, component -> DOM only.
  //   The DOM element reflects the component property, but changes
  //   made by the user in the DOM (e.g. typing) do NOT flow back.
  // [(ngModel)]='value' -> TWO-WAY binding, DOM <-> component.
  //   It is shorthand for [ngModel]='value' (ngModelChange)='value=$event',
  //   so the component property AND the DOM input stay in sync both ways.

  // Hands-On 2, Task 2, Step 16
  ngOnInit(): void {
    // Simulated fetch of available course count
    console.log('HomeComponent initialised — courses loaded');
  }

  // Hands-On 2, Task 2, Step 17
  ngOnDestroy(): void {
    console.log('HomeComponent destroyed');
  }
}
