# Student Course Portal — Hands-On 1, 2 & 3 Solutions

This is a working solution to Hands-On 1–3 of the Digital Nurture 5.0 Angular exercise book,
using standalone components (Angular 20 style).

## How to use
1. Create a fresh CLI project so you get a full workspace: `ng new student-course-portal --routing --style=css`
2. Copy the `src/app` folder from this solution over the generated one (or merge file by file).
3. Run `ng serve` and open http://localhost:4200.

## File map

| File | Hands-On / Task |
|---|---|
| `app.component.*` | HO1 Task 2 — header + router-outlet wired in |
| `components/header/*` | HO1 Task 2 — nav with portal name & links |
| `pages/home/*` | HO1 Task 2 (stats row) + HO2 Task 1 & 2 (bindings, lifecycle hooks) |
| `components/course-card/*` | HO2 Task 2 & 3 (ngOnChanges, @Input/@Output) + HO3 Task 1 & 2 (ngSwitch, ngClass, ngStyle) |
| `pages/course-list/*` | HO2 Task 3 (parent handling enroll events) + HO3 Task 1 (ngIf/ngFor/trackBy, empty state) |
| `directives/highlight.directive.ts` | HO3 Task 3 — custom `appHighlight` directive |
| `pipes/credit-label.pipe.ts` | HO3 Task 3 — custom `creditLabel` pipe |
| `models/course.model.ts` | Shared `Course` interface |

## Notes
- Open the browser console to see the `ngOnInit`, `ngOnDestroy`, and `ngOnChanges` logs from
  Hands-On 2, Task 2.
- Hover over any course card to see the `appHighlight` directive in action.
- Click "Show Details" to toggle the `expanded` class; click "Enroll" to toggle
  enrolled/unenrolled state and the `card--enrolled` class.
